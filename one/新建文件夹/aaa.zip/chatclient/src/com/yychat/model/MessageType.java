package com.yychat.model;

public interface MessageType {
         String message_LoginFailure="0";//�ַ�������
         String message_LoginSuccess="1";
         String message_Common="2";
         String message_Friendlist="3";
         String message_Client="4";
         String message_Newpy="5";
         String message_RegisterSuccess="6";
         String message_RegisterFailure="7";
}	
